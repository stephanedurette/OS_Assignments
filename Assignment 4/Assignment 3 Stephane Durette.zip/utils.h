int cfileexists(const char * filename);
