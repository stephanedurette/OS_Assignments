void hexDump(char* filePath, long unsigned int numBytes, int printASCII);
void hexDumpHelp();
